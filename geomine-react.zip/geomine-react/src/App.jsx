import { useEffect, useState } from "react";
import { sb, BUCKET } from "./supabase";

const pct = (c) => (c == null ? "?" : Math.round(c * 100) + "%");

export default function App() {
  const [user, setUser] = useState(undefined); // undefined = still checking
  const [org, setOrg] = useState(undefined); // undefined = loading, null = none yet
  const [ds, setDs] = useState(null);
  const [msg, setMsg] = useState({ text: "", bad: false });
  const note = (text, bad = false) => setMsg({ text, bad });

  useEffect(() => {
    const { data } = sb.auth.onAuthStateChange((_e, s) => setUser(s?.user ?? null));
    return () => data.subscription.unsubscribe();
  }, []);

  const loadOrg = async () => {
    const { data, error } = await sb.from("memberships").select("role, organizations(id,name)").eq("user_id", user.id);
    if (error) return note(error.message, true);
    setOrg(data.length ? data[0].organizations : null);
  };
  useEffect(() => {
    if (user) loadOrg();
    else { setOrg(undefined); setDs(null); }
  }, [user]);

  let body;
  if (user === undefined) body = <p className="mut">Loading…</p>;
  else if (!user) body = <Auth note={note} />;
  else if (org === undefined) body = <p className="mut">Loading…</p>;
  else if (org === null) body = <OrgSetup note={note} onDone={loadOrg} />;
  else if (ds) body = <DatasetView ds={ds} user={user} note={note} onBack={() => setDs(null)} />;
  else body = <Datasets org={org} user={user} note={note} onOpen={setDs} />;

  return (
    <>
      <header>
        <b>GeoMine</b>
        {user && <span>{user.email} <button className="sec" onClick={() => sb.auth.signOut()}>Sign out</button></span>}
      </header>
      <div id="msg" className={msg.bad ? "err" : "mut"}>{msg.text}</div>
      <main>{body}</main>
    </>
  );
}

/* ---------- Login ---------- */
function Auth({ note }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const go = async (mode) => {
    const creds = { email: email.trim(), password };
    const { error } = mode === "in" ? await sb.auth.signInWithPassword(creds) : await sb.auth.signUp(creds);
    if (error) return note(error.message, true);
    note(mode === "up" ? "Account created. If email confirmation is on, confirm your email, then sign in." : "");
  };
  return (
    <div className="card narrow">
      <h2>Sign in</h2>
      <input className="full" type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input className="full" type="password" placeholder="Password (min 6)" value={password} onChange={(e) => setPassword(e.target.value)} />
      <div className="row">
        <button onClick={() => go("in")}>Sign in</button>
        <button className="sec" onClick={() => go("up")}>Create account</button>
      </div>
    </div>
  );
}

/* ---------- Organization ---------- */
function OrgSetup({ note, onDone }) {
  const [name, setName] = useState("");
  const [kind, setKind] = useState("junior_explorer");
  const create = async () => {
    const { error } = await sb.rpc("create_organization", { p_name: name.trim(), p_kind: kind });
    if (error) return note(error.message, true);
    note(""); onDone();
  };
  return (
    <div className="card narrow">
      <h2>Create your organization</h2>
      <p className="mut">Datasets belong to an organization. You become its owner.</p>
      <input className="full" placeholder="Organization name" value={name} onChange={(e) => setName(e.target.value)} />
      <select className="full" value={kind} onChange={(e) => setKind(e.target.value)}>
        <option value="junior_explorer">Junior explorer</option>
        <option value="university">University</option>
        <option value="government">Government</option>
        <option value="other">Other</option>
      </select>
      <button onClick={create}>Create</button>
    </div>
  );
}

/* ---------- Datasets ---------- */
function Datasets({ org, user, note, onOpen }) {
  const [list, setList] = useState([]);
  const blank = { name: "", visibility: "private", source_name: "", licence_terms: "", licence_ref: "", redistribution_allowed: false };
  const [f, setF] = useState(blank);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });

  const load = async () => {
    const { data } = await sb.from("datasets").select("*").eq("owner_org_id", org.id).order("created_at", { ascending: false });
    setList(data || []);
  };
  useEffect(() => { load(); }, [org.id]);

  const create = async () => {
    const row = { ...f, name: f.name.trim(), owner_org_id: org.id, created_by: user.id };
    for (const k of ["source_name", "licence_terms", "licence_ref"]) row[k] = row[k] || null;
    const { error } = await sb.from("datasets").insert(row);
    if (error) return note(error.message, true);
    note(""); setF(blank); load();
  };

  return (
    <>
      <h2>{org.name}</h2>
      <div className="card">
        <h3>Datasets</h3>
        {list.length === 0 && <p className="mut">No datasets yet.</p>}
        {list.map((d) => (
          <div key={d.id} className="row between" style={{ borderBottom: "1px solid var(--bd)", padding: "6px 0" }}>
            <span><b>{d.name}</b> <span className="mut">{d.visibility}{d.source_name ? " · " + d.source_name : ""}</span></span>
            <button onClick={() => onOpen(d)}>Open</button>
          </div>
        ))}
      </div>
      <div className="card">
        <h3>New dataset</h3>
        <input className="full" placeholder="Name" value={f.name} onChange={set("name")} />
        <div className="row">
          <select value={f.visibility} onChange={set("visibility")}>
            <option value="private">Private</option>
            <option value="shared">Shared (readable by all signed-in users)</option>
          </select>
          <input placeholder="Source (e.g. GSD Digital Store)" value={f.source_name} onChange={set("source_name")} />
        </div>
        <input className="full" placeholder="Licence terms" value={f.licence_terms} onChange={set("licence_terms")} />
        <input className="full" placeholder="Licence / purchase reference" value={f.licence_ref} onChange={set("licence_ref")} />
        <label><input type="checkbox" checked={f.redistribution_allowed} onChange={set("redistribution_allowed")} /> Licence allows redistribution of the original files</label>
        <div><button onClick={create}>Create dataset</button></div>
      </div>
    </>
  );
}

/* ---------- One dataset: upload, extract, review ---------- */
function DatasetView({ ds, user, note, onBack }) {
  const [docs, setDocs] = useState([]);
  const [busy, setBusy] = useState(null);
  const [file, setFile] = useState(null);
  const blank = { title: "", doc_type: "report", author: "", year: "", ref: "" };
  const [f, setF] = useState(blank);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const loadDocs = async () => {
    const { data } = await sb.from("source_documents").select("*").eq("dataset_id", ds.id).order("uploaded_at", { ascending: false });
    setDocs(data || []);
  };
  useEffect(() => { loadDocs(); }, [ds.id]);

  const upload = async () => {
    if (!file) return note("Choose a file first.", true);
    if (file.size > 18 * 1024 * 1024) return note("File is over 18 MB. Split it first.", true);
    note("Uploading…");
    const digest = await crypto.subtle.digest("SHA-256", await file.arrayBuffer());
    const hash = [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
    const path = `${ds.id}/${hash}.${file.name.split(".").pop().toLowerCase()}`;
    const up = await sb.storage.from(BUCKET).upload(path, file);
    if (up.error && !/exist/i.test(up.error.message)) return note("Upload failed: " + up.error.message, true);
    const { error } = await sb.from("source_documents").insert({
      dataset_id: ds.id, title: f.title.trim() || file.name, doc_type: f.doc_type, storage_path: path, sha256: hash,
      original_author: f.author || null, original_year: parseInt(f.year) || null, original_ref: f.ref || null, uploaded_by: user.id,
    });
    if (error) return note(/duplicate/i.test(error.message) ? "This file is already in the dataset." : error.message, true);
    note("Uploaded."); setF(blank); setFile(null); loadDocs();
  };

  const extract = async (id) => {
    setBusy(id); note("Extraction can take a minute or two.");
    const { data, error } = await sb.functions.invoke("extract-document", { body: { document_id: id } });
    if (error) {
      let m = error.message;
      try { m = (await error.context.json()).error || m; } catch { /* keep default message */ }
      note(m, true);
    } else note(`Done: ${data.records} records found, ${data.flagged} flagged for checking.`);
    setBusy(null); loadDocs();
  };

  return (
    <>
      <p><a href="#" onClick={(e) => { e.preventDefault(); onBack(); }}>&larr; Datasets</a></p>
      <h2>{ds.name}</h2>
      <div className="card">
        <h3>Upload a document</h3>
        <input type="file" accept=".pdf,.png,.jpg,.jpeg" onChange={(e) => setFile(e.target.files[0])} />
        <span className="mut"> PDF or image, up to 18 MB</span>
        <div className="row">
          <input placeholder="Title" value={f.title} onChange={set("title")} />
          <select value={f.doc_type} onChange={set("doc_type")}>
            {["report", "map", "borehole_log", "assay_sheet", "field_notebook", "table", "other"].map((x) => <option key={x}>{x}</option>)}
          </select>
        </div>
        <div className="row">
          <input placeholder="Original author" value={f.author} onChange={set("author")} />
          <input placeholder="Year" size="6" value={f.year} onChange={set("year")} />
          <input placeholder="Archive / report ref" value={f.ref} onChange={set("ref")} />
        </div>
        <button onClick={upload}>Upload</button>
      </div>
      <div className="card">
        <h3>Documents</h3>
        <table>
          <thead><tr><th>Title</th><th>Type</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {docs.length === 0 && <tr><td colSpan="4" className="mut">No documents yet.</td></tr>}
            {docs.map((d) => (
              <tr key={d.id}>
                <td>{d.title}</td><td>{d.doc_type}</td><td>{d.status}</td>
                <td>{d.status !== "extracted" && <button disabled={busy === d.id} onClick={() => extract(d.id)}>{busy === d.id ? "Extracting…" : "Extract"}</button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Review docs={docs} user={user} note={note} />
    </>
  );
}

/* ---------- Review queue ---------- */
function Review({ docs, user, note }) {
  const [rows, setRows] = useState(null);
  const [vals, setVals] = useState({});

  const load = async () => {
    const ids = docs.map((d) => d.id);
    if (!ids.length) return setRows([]);
    const { data, error } = await sb.from("review_queue").select("*").in("document_id", ids)
      .order("confidence", { ascending: true, nullsFirst: true }).limit(60);
    if (error) return note(error.message, true);
    setRows(data);
    setVals(Object.fromEntries(data.map((r) => [r.id, r.extracted_value ?? ""])));
  };
  useEffect(() => { load(); }, [docs]);

  const openPage = async (docId, page) => {
    const d = docs.find((x) => x.id === docId);
    const { data, error } = await sb.storage.from(BUCKET).createSignedUrl(d.storage_path, 300);
    if (error) return note(error.message, true);
    window.open(`${data.signedUrl}#page=${page}`, "_blank");
  };

  const decide = async (r, action) => {
    const val = (vals[r.id] ?? "").trim();
    let status = action, corrected = null;
    if (action === "confirm") {
      if (val !== (r.extracted_value ?? "").trim()) { status = "corrected"; corrected = val; } else status = "accepted";
    }
    if (status === "corrected" && !(await applyFix(r.record_id, r.field_name, val, note))) return;
    const { error } = await sb.from("extracted_fields").update({
      review: status, corrected_value: corrected, reviewed_by: user.id, reviewed_at: new Date().toISOString(),
    }).eq("id", r.id);
    if (error) return note(error.message, true);
    await finishRecord(r.record_id);
    note(""); load();
  };

  return (
    <div className="card">
      <h3>Review queue</h3>
      <p className="mut">Lowest confidence first. Edit a value if it is wrong, then Confirm.</p>
      {rows === null ? <span className="mut">Loading…</span> : rows.length === 0 ? <span className="mut">Nothing waiting for review.</span> : (
        <table>
          <thead><tr><th>Field</th><th>Value</th><th>Conf.</th><th>Source</th><th></th></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td>{r.field_name}</td>
                <td><input className="full" value={vals[r.id] ?? ""} onChange={(e) => setVals({ ...vals, [r.id]: e.target.value })} /></td>
                <td className={(r.confidence ?? 0) < 0.6 ? "low" : ""}>{pct(r.confidence)}</td>
                <td><a href="#" onClick={(e) => { e.preventDefault(); openPage(r.document_id, r.page_number || 1); }}>p.{r.page_number || "?"}</a></td>
                <td>
                  <button onClick={() => decide(r, "confirm")}>Confirm</button>{" "}
                  <button className="sec" onClick={() => decide(r, "rejected")}>Reject</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

// Writes a human correction back to the record itself
async function applyFix(recordId, field, val, note) {
  const patch = {};
  if (field === "name" || field === "deposit_type") patch[field] = val || null;
  else if (field === "commodities") patch.commodities = val.replace(/[[\]"]/g, "").split(",").map((s) => s.trim()).filter(Boolean);
  else if (field === "location") {
    const m = val.match(/(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)/);
    const lat = m && +m[1], lon = m && +m[2];
    if (!m || lat > -8.2 || lat < -18.1 || lon < 21.9 || lon > 33.7) {
      note('Location must be "latitude, longitude" inside Zambia, e.g. -12.8, 28.2', true);
      return false;
    }
    patch.location = `SRID=4326;POINT(${lon} ${lat})`;
  }
  const { error } = await sb.from("mineral_occurrences").update(patch).eq("id", recordId);
  if (error) { note(error.message, true); return false; }
  return true;
}

// Once every field of a record is decided, mark the record itself as reviewed
async function finishRecord(recordId) {
  const { data } = await sb.from("extracted_fields").select("review").eq("record_id", recordId);
  if (!data || data.some((f) => f.review === "pending")) return;
  const r = data.map((f) => f.review);
  const status = r.every((x) => x === "rejected") ? "rejected" : r.includes("corrected") || r.includes("rejected") ? "corrected" : "accepted";
  await sb.from("mineral_occurrences").update({ record_review: status }).eq("id", recordId);
}
